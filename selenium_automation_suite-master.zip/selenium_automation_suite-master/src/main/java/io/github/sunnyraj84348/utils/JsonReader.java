package io.github.sunnyraj84348.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Map;

public final class JsonReader {
    private static final Logger logger = LoggerFactory.getLogger(JsonReader.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    private JsonReader() {
    }

    /**
     * Read JSON as a single POJO
     *
     * @param path  classpath location (e.g. testdata/user.json)
     * @param clazz POJO class
     */
    public static <T> T readAsPojo(String path, Class<T> clazz) {
        try (InputStream is = getInputStream(path)) {
            T value = mapper.readValue(is, clazz);
            logger.info("Successfully read JSON as POJO: {}", path);
            return value;
        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to read JSON as POJO: " + path, e
            );
        }
    }

    /**
     * Read JSON as Map<String, T>
     *
     * @param path    classpath location (e.g. testdata/login.json)
     * @param typeRef TypeReference for Map<String, T>
     */
    public static <T> Map<String, T> readAsMap(
            String path,
            TypeReference<Map<String, T>> typeRef) {

        try (InputStream is = getInputStream(path)) {
            Map<String, T> value = mapper.readValue(is, typeRef);
            logger.info("Successfully read JSON as Map: {}", path);
            return value;
        } catch (Exception e) {
            throw new RuntimeException(
                    "Failed to read JSON as Map: " + path, e
            );
        }
    }

    /**
     * Centralized classpath loader
     */
    private static InputStream getInputStream(String path) {
        InputStream is = JsonReader.class
                .getClassLoader()
                .getResourceAsStream(path);

        if (is == null) {
            throw new RuntimeException(
                    "JSON file not found on classpath: " + path
            );
        }
        return is;
    }
}
