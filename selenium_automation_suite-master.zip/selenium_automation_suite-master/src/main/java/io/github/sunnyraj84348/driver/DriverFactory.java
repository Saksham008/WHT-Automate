package io.github.sunnyraj84348.driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverFactory {
    private static final ThreadLocal<WebDriver> drivers = new ThreadLocal<>();

    /**
     * Initializes WebDriver based on browser type and fails fast when unsupported.
     *
     * @param browser browser name such as chrome, firefox, or edge
     */
    public static void initDriver(String browser) {
        if (drivers.get() != null) {
            return;
        }

        switch (browser.toLowerCase()) {
            case "chrome":
                drivers.set(new ChromeDriver());
                break;

            case "firefox":
                drivers.set(new FirefoxDriver());
                break;

            case "edge":
                drivers.set(new EdgeDriver());
                break;

            default:
                throw new IllegalArgumentException("Unsupported browser: " + browser);
        }
    }

    public static WebDriver getDriver() {
        return drivers.get();
    }

    public static void quitDriver() {
        if (drivers.get() != null) {
            drivers.get().quit();
            drivers.remove();
        }
    }
}
