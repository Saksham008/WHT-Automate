package io.github.sunnyraj84348.utils;

import io.github.sunnyraj84348.constants.FrameworkConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Properties;

public final class PropertyReader {
    private static final Logger logger = LoggerFactory.getLogger(PropertyReader.class);
    private static final Properties props = new Properties();

    private PropertyReader() {
    }

    /**
     * Loads config properties once at class-load time so every subsequent call can reuse them.
     */
    static {
        try (InputStream is =
                     PropertyReader.class.getClassLoader()
                             .getResourceAsStream(FrameworkConstants.CONFIG_FILE_PATH)) {

            if (is == null) {
                throw new RuntimeException("config.properties not found: " + FrameworkConstants.CONFIG_FILE_PATH);
            }

            props.load(is);
            logger.info("Successfully loaded config properties from path: {}", FrameworkConstants.CONFIG_FILE_PATH);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load config.properties", e);
        }
    }

    public static String get(String key) {
        String value = props.getProperty(key);

        if (value == null || value.isBlank()) {
            throw new RuntimeException(
                    "Required property '" + key + "' is missing in config.properties"
            );
        }

        return value;
    }
}
