package io.github.sunnyraj84348.constants;

public final class FrameworkConstants {
    private FrameworkConstants() {
    }

    public static final String CONFIG_FILE_PATH = "config/config.properties";

}
