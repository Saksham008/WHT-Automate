package io.github.sunnyraj84348.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

public class EntityPage {
    private static final Logger logger = LoggerFactory.getLogger(EntityPage.class);
    private final WebDriver driver;

    public EntityPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "/html/body/div/div/div[3]/main/div/div[2]/div/div/div[1]/h6")
    private WebElement entityText;

    public boolean isEntityTextVisible() {
        logger.debug("Checking if Entity text is visible on admin page");
        try {
            logger.debug("Waiting for Entity text element to be visible...");
            new WebDriverWait(driver, Duration.ofSeconds(30))
                    .until(ExpectedConditions.visibilityOf(entityText));
            logger.debug("Entity text element found!");
            String textContent = entityText.getText();
            logger.debug("Entity text content: {}", textContent);
            boolean isDisplayed = entityText.isDisplayed();
            boolean containsEntity = textContent.contains("Entity");
            logger.info("Entity text visibility: {}, Contains 'Entity': {}", isDisplayed, containsEntity);
            return isDisplayed && containsEntity;
        } catch (Exception e) {
            logger.error("❌ Error finding Entity text: {}", e.getMessage());
            logger.error("Current URL: {}", driver.getCurrentUrl());
            logger.error("Page title: {}", driver.getTitle());
            throw e;
        }
    }
}
