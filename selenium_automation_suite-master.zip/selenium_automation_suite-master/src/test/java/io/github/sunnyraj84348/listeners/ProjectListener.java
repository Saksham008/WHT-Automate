package io.github.sunnyraj84348.listeners;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import io.github.sunnyraj84348.utils.ExtentReportManager;
import io.github.sunnyraj84348.utils.ScreenshotManager;
import io.github.sunnyraj84348.utils.PropertyReader;
import io.github.sunnyraj84348.utils.EmailManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ProjectListener implements ITestListener {
    private static final Logger logger = LoggerFactory.getLogger(ProjectListener.class);

    @Override
    public void onStart(org.testng.ITestContext context) {
        logger.info("========================================");
        logger.info("Test Suite Started: {}", context.getName());
        logger.info("========================================");
        ExtentReportManager.initReports();
    }

    @Override
    public void onTestStart(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        String testClass = result.getTestClass().getRealClass().getSimpleName();
        String description = result.getMethod().getDescription() != null ?
                result.getMethod().getDescription() : "No description provided";

        logger.info("========================================");
        logger.info("Test Started: {}.{}", testClass, testName);
        logger.info("Description: {}", description);
        logger.info("========================================");

        /* Adding test class and method name to MDC (Mapped Diagnostic Context) for better logging.
         * This allows us to see which test class and method is currently being executed in the logs.
         */
        MDC.put("testClass", testClass);
        MDC.put("testMethod", testName);

        // Create test entry in Extent Reports
        ExtentTest extentTest = ExtentReportManager.createTest(testName, description);
        extentTest.info("Test execution started for: " + testClass + "." + testName);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        logger.info("✅ Test PASSED: {}", testName);

        ExtentTest extentTest = ExtentReportManager.getTest();
        if (extentTest != null) {
            extentTest.pass("✅ Test PASSED");
            extentTest.addScreenCaptureFromBase64String(ScreenshotManager.getScreenshotAsBase64(),
                    testName + " - PASSED");
        }

        MDC.clear();
        ExtentReportManager.removeTest();
    }

    @Override
    public void onTestFailure(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        String errorMessage = result.getThrowable() != null ? result.getThrowable().getMessage() : "Unknown error";

        logger.error("❌ Test FAILED: {}", testName);
        logger.error("Error Message: {}", errorMessage);
        logger.error("Stack Trace: ", result.getThrowable());

        ExtentTest extentTest = ExtentReportManager.getTest();
        if (extentTest != null) {
            extentTest.fail("❌ Test FAILED");
            extentTest.fail("Error: " + errorMessage);
            extentTest.addScreenCaptureFromBase64String(ScreenshotManager.getScreenshotAsBase64(),
                    testName + " - FAILED");
        }

        MDC.clear();
        ExtentReportManager.removeTest();
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        String testName = result.getMethod().getMethodName();
        logger.warn("⏭️  Test SKIPPED: {}", testName);

        ExtentTest extentTest = ExtentReportManager.getTest();
        if (extentTest != null) {
            extentTest.skip("⏭️  Test SKIPPED");
            if (result.getThrowable() != null) {
                extentTest.skip("Reason: " + result.getThrowable().getMessage());
            }
        }

        MDC.clear();
        ExtentReportManager.removeTest();
    }

    @Override
    public void onFinish(org.testng.ITestContext context) {
        logger.info("========================================");
        logger.info("Test Suite Completed: {}", context.getName());
        logger.info("Total Tests Run: {}", context.getAllTestMethods().length);
        logger.info("Passed: {}", context.getPassedTests().size());
        logger.info("Failed: {}", context.getFailedTests().size());
        logger.info("Skipped: {}", context.getSkippedTests().size());
        logger.info("========================================");

        // Flush Extent Reports
        ExtentReportManager.flushReports();

        // Attempt to send report via email if configured
        try {
            // Read mail.enabled and mail.recipient from config (mail.enabled optional)
            boolean mailEnabled = true;
            try {
                String mailEnabledStr = PropertyReader.get("mail.enabled");
                mailEnabled = Boolean.parseBoolean(mailEnabledStr.trim());
            } catch (Exception e) {
                // property missing - default to true (but recipient must be present)
                mailEnabled = true;
            }

            if (mailEnabled) {
                String recipient = null;
                try {
                  recipient = PropertyReader.get("mail.recipient");
                 } catch (Exception e) {
                     logger.warn("mail.recipient not configured in config.properties; skipping email send.");
                 }

                 if (recipient != null && !recipient.isBlank()) {
                     int total = context.getAllTestMethods().length;
                     int passed = context.getPassedTests().size();
                     int failed = context.getFailedTests().size();
                     int skipped = context.getSkippedTests().size();

                     // Build TestStats expected by EmailManager
                     EmailManager.TestStats stats = new EmailManager.TestStats(
                             total, passed, failed, skipped,
                             "N/A", // execution time - not tracked here
                             java.time.LocalDateTime.now().toString()
                     );

                     String reportPath = ExtentReportManager.getLastReportFilePath();
                     if (reportPath == null) {
                         logger.warn("Extent report path is null - cannot attach report to email");
                     } else {
                         logger.info("Sending Extent report via email to: {}", recipient);
                         EmailManager.sendReportEmail(recipient, reportPath, stats);
                     }
                 }
             }
         } catch (Exception e) {
             logger.error("Failed to send Extent report via email: {}", e.getMessage(), e);
         }


     }
 }
