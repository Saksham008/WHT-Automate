package io.github.sunnyraj84348.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.util.Properties;

/**
 * Utility class for sending test reports via email
 */
public class EmailManager {
    private static final Logger logger = LoggerFactory.getLogger(EmailManager.class);
    
    // Email configuration - read from environment variables for security
    private static final String SMTP_HOST = System.getenv("MAIL_HOST") != null ? System.getenv("MAIL_HOST") : "smtp.gmail.com";
    private static final String SMTP_PORT = System.getenv("MAIL_PORT") != null ? System.getenv("MAIL_PORT") : "587";
    private static final String SENDER_EMAIL = System.getenv("MAIL_USERNAME");  // must be provided via env var
    private static final String SENDER_PASSWORD = System.getenv("MAIL_PASSWORD");  // must be provided via env var

    /**
     * Send test report via email
     * @param recipientEmail - Email address of recipient
     * @param reportFilePath - Path to the Extent Report HTML file
     * @param testStats - Test statistics summary
     */
    public static void sendReportEmail(String recipientEmail, String reportFilePath, TestStats testStats) {
        try {
            logger.info("Preparing to send test report to: {}", recipientEmail);
            
            // Validate inputs
            if (recipientEmail == null || recipientEmail.trim().isEmpty()) {
                logger.warn("Recipient email is empty. Email will not be sent.");
                return;
            }

            if (SENDER_EMAIL == null || SENDER_EMAIL.trim().isEmpty() || SENDER_PASSWORD == null || SENDER_PASSWORD.trim().isEmpty()) {
                logger.warn("Email sender credentials are not configured via environment variables (MAIL_USERNAME / MAIL_PASSWORD). Skipping email send.");
                return;
            }

            File reportFile = new File(reportFilePath);
            if (!reportFile.exists()) {
                logger.error("Report file not found: {}", reportFilePath);
                return;
            }
            
            // Setup email properties
            Properties props = new Properties();
            props.put("mail.smtp.host", SMTP_HOST);
            props.put("mail.smtp.port", SMTP_PORT);
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.starttls.required", "true");
            props.put("mail.smtp.connectiontimeout", "5000");
            props.put("mail.smtp.timeout", "5000");
            
            // Create session with authentication
            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
                }
            });
            
            // Create message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(SENDER_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Test Automation Report - " + testStats.getStatus());
            
            // Create email body
            String emailBody = buildEmailBody(testStats, reportFile);
            
            // Create multipart message
            MimeMultipart multipart = new MimeMultipart();
            
            // Add text content
            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setText(emailBody, "utf-8", "html");
            multipart.addBodyPart(textPart);
            
            // Add HTML report as attachment
            MimeBodyPart attachmentPart = new MimeBodyPart();
            attachmentPart.attachFile(reportFile);
            attachmentPart.setFileName("ExtentReport.html");
            multipart.addBodyPart(attachmentPart);
            
            message.setContent(multipart);
            
            // Send email
            Transport.send(message);
            logger.info("✅ Test report email sent successfully to: {}", recipientEmail);
            
        } catch (AuthenticationFailedException e) {
            logger.error("❌ Email authentication failed. Please check your email credentials.", e);
        } catch (MessagingException e) {
            logger.error("❌ Error sending email: {}", e.getMessage(), e);
        } catch (Exception e) {
            logger.error("❌ Unexpected error while sending email: {}", e.getMessage(), e);
        }
    }
    
    /**
     * Build HTML email body with test statistics
     */
    private static String buildEmailBody(TestStats stats, File reportFile) {
        String statusColor = stats.getFailedCount() == 0 ? "#28a745" : "#dc3545";
        String statusIcon = stats.getFailedCount() == 0 ? "✅" : "❌";
        
        return "<html>" +
                "<body style='font-family: Arial, sans-serif; margin: 20px;'>" +
                "<div style='border: 2px solid " + statusColor + "; border-radius: 8px; padding: 20px; background-color: #f9f9f9;'>" +
                "<h2 style='color: " + statusColor + "; margin-top: 0;'>" + statusIcon + " Test Automation Report</h2>" +
                "<div style='background-color: white; padding: 15px; border-radius: 5px; margin: 15px 0;'>" +
                "<h3 style='margin-top: 0; color: #333;'>Test Summary</h3>" +
                "<table style='width: 100%; border-collapse: collapse;'>" +
                "<tr style='background-color: #f5f5f5;'>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>Total Tests</strong></td>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'>" + stats.getTotalTests() + "</td>" +
                "</tr>" +
                "<tr>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>Passed ✅</strong></td>" +
                "<td style='padding: 10px; border: 1px solid #ddd; color: #28a745;'><strong>" + stats.getPassedCount() + "</strong></td>" +
                "</tr>" +
                "<tr style='background-color: #f5f5f5;'>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>Failed ❌</strong></td>" +
                "<td style='padding: 10px; border: 1px solid #ddd; color: #dc3545;'><strong>" + stats.getFailedCount() + "</strong></td>" +
                "</tr>" +
                "<tr>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>Skipped ⏭️</strong></td>" +
                "<td style='padding: 10px; border: 1px solid #ddd; color: #ffc107;'><strong>" + stats.getSkippedCount() + "</strong></td>" +
                "</tr>" +
                "<tr style='background-color: #f5f5f5;'>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>Success Rate</strong></td>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>" + stats.getSuccessRate() + "%</strong></td>" +
                "</tr>" +
                "<tr>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>Execution Time</strong></td>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'>" + stats.getExecutionTime() + "</td>" +
                "</tr>" +
                "<tr style='background-color: #f5f5f5;'>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'><strong>Timestamp</strong></td>" +
                "<td style='padding: 10px; border: 1px solid #ddd;'>" + stats.getTimestamp() + "</td>" +
                "</tr>" +
                "</table>" +
                "</div>" +
                "<div style='background-color: #e8f5e9; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #28a745;'>" +
                "<p style='margin: 0;'><strong>📎 Attachment:</strong> ExtentReport.html - Open this file in a browser to view detailed test results with screenshots.</p>" +
                "</div>" +
                "<div style='background-color: #fff3cd; padding: 15px; border-radius: 5px; margin: 15px 0; border-left: 4px solid #ffc107;'>" +
                "<p style='margin: 0;'><strong>ℹ️ Note:</strong> This is an automated email from the Selenium Automation Suite. Please do not reply to this email.</p>" +
                "</div>" +
                "<hr style='margin: 20px 0; border: none; border-top: 1px solid #ddd;'>" +
                "<p style='color: #999; font-size: 12px; margin-bottom: 0;'>" +
                "Selenium Automation Suite | PWC Withholding Tax<br>" +
                "Report Generated: " + stats.getTimestamp() +
                "</p>" +
                "</div>" +
                "</body>" +
                "</html>";
    }
    
    /**
     * Test statistics class
     */
    public static class TestStats {
        private int totalTests;
        private int passedCount;
        private int failedCount;
        private int skippedCount;
        private double successRate;
        private String executionTime;
        private String timestamp;
        
        public TestStats(int total, int passed, int failed, int skipped, String execTime, String time) {
            this.totalTests = total;
            this.passedCount = passed;
            this.failedCount = failed;
            this.skippedCount = skipped;
            this.successRate = total > 0 ? (double) passed / total * 100 : 0;
            this.executionTime = execTime;
            this.timestamp = time;
        }
        
        public String getStatus() {
            return failedCount == 0 ? "PASSED ✅" : "FAILED ❌";
        }
        
        // Getters
        public int getTotalTests() { return totalTests; }
        public int getPassedCount() { return passedCount; }
        public int getFailedCount() { return failedCount; }
        public int getSkippedCount() { return skippedCount; }
        public String getSuccessRate() { return String.format("%.2f", successRate); }
        public String getExecutionTime() { return executionTime; }
        public String getTimestamp() { return timestamp; }
    }
}

