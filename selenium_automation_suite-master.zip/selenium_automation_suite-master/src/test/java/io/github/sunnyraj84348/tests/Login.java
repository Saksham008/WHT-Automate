package io.github.sunnyraj84348.tests;

import io.github.sunnyraj84348.base.BaseTest;
import io.github.sunnyraj84348.driver.DriverFactory;
import io.github.sunnyraj84348.pages.LoginPage;
import io.github.sunnyraj84348.pages.EntityPage;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Login extends BaseTest {
    private static final Logger log = LoggerFactory.getLogger(Login.class);

    /**
     * Priority 1: Test empty login without any credentials
     * Expected: HTML5 validation should prevent form submission
     * The "Please fill in this field" message is a browser validation popup (not a DOM element)
     */
    @Test(priority = 1, description = "Verify empty login without credentials is blocked by HTML5 validation")
    public void verifyEmptyLogin() {
        log.info("Starting test: verifyEmptyLogin");
        WebDriver driver = DriverFactory.getDriver();
        LoginPage loginPage = new LoginPage(driver);
        SoftAssert softAssert = new SoftAssert();

        log.debug("Verifying WHT heading is visible on login page");
        softAssert.assertTrue(loginPage.isWhtHeadingVisible(), "WHT heading should be visible on login page");

        // Get current URL before attempting login
        String urlBefore = driver.getCurrentUrl();
        log.debug("URL before login attempt: {}", urlBefore);

        // Attempting login with empty credentials
        log.debug("Attempting to login with empty credentials");
        loginPage.login("", "");

        // Wait a bit for any validation to occur
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Check if the page URL hasn't changed (form submission was blocked by HTML5 validation)
        String urlAfter = driver.getCurrentUrl();
        log.debug("URL after login attempt: {}", urlAfter);

        boolean isStillOnLoginPage = urlBefore.equals(urlAfter);
        log.info("Form submission blocked by HTML5 validation: {}", isStillOnLoginPage);

        softAssert.assertTrue(isStillOnLoginPage,
            "Form should not submit with empty credentials - should be blocked by HTML5 validation");
        log.info("✅ Empty login test passed - HTML5 validation prevented form submission");

        softAssert.assertAll();
        log.info("Test verifyEmptyLogin completed successfully");
    }

    /**
     * Priority 2: Test invalid login with data provider
     * Expected: Error message should be displayed for each invalid credential set
     */
    @Test(
            priority = 2,
            dataProvider = "loginData1",
            dataProviderClass = io.github.sunnyraj84348.dataproviders.LoginDataProvider.class,
            description = "Verify invalid login credentials show error message"
    )
    public void verifyInvalidLogin(String username, String password) {
        log.info("Starting test: verifyInvalidLogin with username: {} and password: {}", username, password);
        WebDriver driver = DriverFactory.getDriver();
        LoginPage loginPage = new LoginPage(driver);
        SoftAssert softAssert = new SoftAssert();

        log.debug("Verifying WHT heading is visible on login page");
        softAssert.assertTrue(loginPage.isWhtHeadingVisible(), "WHT heading should be visible on login page");

        // Attempting login with the given username and password
        log.debug("Attempting login with invalid credentials - username: {}", username);
        loginPage.login(username, password);
        log.debug("Submitted login form with invalid credentials");

        // Check for the error message on invalid credentials
        log.debug("Checking for error message on invalid login attempt");
        softAssert.assertTrue(loginPage.isErrorMessageVisible(), "Error message should be visible for invalid credentials");
        log.info("✅ Invalid login test passed - error message displayed for username: {}", username);

        softAssert.assertAll();
        log.info("Test verifyInvalidLogin completed successfully");
    }

    /**
     * Priority 3: Test invalid username with valid password format
     * Expected: Error message should be displayed
     */
    @Test(priority = 3, description = "Verify invalid username with valid password format shows error message")
    public void verifyInvalidUsername() {
        log.info("Starting test: verifyInvalidUsername");
        WebDriver driver = DriverFactory.getDriver();
        LoginPage loginPage = new LoginPage(driver);
        SoftAssert softAssert = new SoftAssert();

        log.debug("Verifying WHT heading is visible on login page");
        softAssert.assertTrue(loginPage.isWhtHeadingVisible(), "WHT heading should be visible on login page");

        // Attempting login with invalid username
        log.debug("Attempting login with invalid username: invalidUsername");
        loginPage.login("invalidUsername", "validPassword");
        log.debug("Submitted login form with invalid username");

        // Check for the error message on invalid username
        log.debug("Checking for error message on invalid username attempt");
        softAssert.assertTrue(loginPage.isErrorMessageVisible(), "Error message should be visible for invalid username");
        log.info("✅ Invalid username test passed - error message displayed");

        softAssert.assertAll();
        log.info("Test verifyInvalidUsername completed successfully");
    }

    /**
     * Priority 4: Test valid username with invalid password
     * Expected: Error message should be displayed
     */
    @Test(priority = 4, description = "Verify valid username with invalid password shows error message")
    public void verifyInvalidPassword() {
        log.info("Starting test: verifyInvalidPassword");
        WebDriver driver = DriverFactory.getDriver();
        LoginPage loginPage = new LoginPage(driver);
        SoftAssert softAssert = new SoftAssert();

        log.debug("Verifying WHT heading is visible on login page");
        softAssert.assertTrue(loginPage.isWhtHeadingVisible(), "WHT heading should be visible on login page");

        // Attempting login with invalid password
        log.debug("Attempting login with valid username but invalid password");
        loginPage.login("itadmin_wht_qa", "iita@1234");
        log.debug("Submitted login form with invalid password");

        // Check for the error message on invalid password
        log.debug("Checking for error message on invalid password attempt");
        softAssert.assertTrue(loginPage.isErrorMessageVisible(), "Error message should be visible for invalid password");
        log.info("✅ Invalid password test passed - error message displayed");

        softAssert.assertAll();
        log.info("Test verifyInvalidPassword completed successfully");
    }

    /**
     * Priority 5: Test valid login and navigate to admin page
     * Expected: Dashboard should be visible, navigate to admin, and entity page should be displayed
     */
    @Test(
            priority = 5,
            dataProvider = "loginData2",
            dataProviderClass = io.github.sunnyraj84348.dataproviders.LoginDataProvider.class,
            description = "Verify valid login succeeds and navigation to admin page works"
    )
    public void verifyValidLoginAndNavigateToAdmin(String username, String password) {
        log.info("Starting test: verifyValidLoginAndNavigateToAdmin with username: {}", username);
        WebDriver driver = DriverFactory.getDriver();
        LoginPage loginPage = new LoginPage(driver);
        SoftAssert softAssert = new SoftAssert();

        log.debug("Verifying WHT heading is visible on login page");
        softAssert.assertTrue(loginPage.isWhtHeadingVisible(), "WHT heading should be visible on login page");

        // Attempting valid login
        log.info("Attempting login with valid credentials - username: {}", username);
        loginPage.login(username, password);
        log.debug("Submitted login form with valid credentials");

        // Check if the dashboard page text appears for successful login
        log.debug("Verifying dashboard text is visible after successful login");
        softAssert.assertTrue(loginPage.isDashboardTextVisible(), "Dashboard text should be visible for valid login");
        log.info("✅ Dashboard text verified - valid login successful");

        // Navigate to Admin page
        log.info("Navigating to admin page");
        loginPage.navigateToAdminPage();
        log.debug("Successfully navigated to admin page");

        // Create EntityPage instance
        EntityPage entityPage = new EntityPage(driver);

        // Check if the Entity page is displayed
        log.debug("Verifying entity text is visible on admin page");
        softAssert.assertTrue(entityPage.isEntityTextVisible(), "Entity text should be visible after navigating to Entity page");
        log.info("✅ Entity page verified - successfully navigated to admin page");

        softAssert.assertAll();
        log.info("Test verifyValidLoginAndNavigateToAdmin completed successfully");
    }
}
