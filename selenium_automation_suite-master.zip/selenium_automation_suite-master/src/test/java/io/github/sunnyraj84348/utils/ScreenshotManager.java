package io.github.sunnyraj84348.utils;

import io.github.sunnyraj84348.driver.DriverFactory;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ScreenshotManager {
    private static final Logger logger = LoggerFactory.getLogger(ScreenshotManager.class);
    private static final String SCREENSHOT_PATH = "test-output/Screenshots/";

    /**
     * Take a screenshot and save it to the file system
     * @param screenshotName - Name of the screenshot file
     * @return - Path to the saved screenshot
     */
    public static String takeScreenshot(String screenshotName) {
        try {
            // Create screenshots directory if it doesn't exist
            Files.createDirectories(Paths.get(SCREENSHOT_PATH));

            WebDriver driver = DriverFactory.getDriver();
            if (driver == null) {
                logger.error("WebDriver is null. Cannot take screenshot.");
                return null;
            }

            TakesScreenshot screenshot = (TakesScreenshot) driver;
            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);

            String timeStamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss-SSS"));
            String destinationPath = SCREENSHOT_PATH + screenshotName + "_" + timeStamp + ".png";

            File destFile = new File(destinationPath);
            Files.copy(srcFile.toPath(), destFile.toPath());

            logger.info("Screenshot saved: {}", destinationPath);
            return destinationPath;
        } catch (IOException e) {
            logger.error("Failed to take screenshot: {}", e.getMessage());
            return null;
        } catch (Exception e) {
            logger.error("Unexpected error while taking screenshot: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Get screenshot as base64 string for embedding in reports
     * @return - Base64 encoded screenshot string
     */
    public static String getScreenshotAsBase64() {
        try {
            WebDriver driver = DriverFactory.getDriver();
            if (driver == null) {
                logger.error("WebDriver is null. Cannot take screenshot.");
                return null;
            }

            TakesScreenshot screenshot = (TakesScreenshot) driver;
            return screenshot.getScreenshotAs(OutputType.BASE64);
        } catch (Exception e) {
            logger.error("Failed to get base64 screenshot: {}", e.getMessage());
            return null;
        }
    }
}

