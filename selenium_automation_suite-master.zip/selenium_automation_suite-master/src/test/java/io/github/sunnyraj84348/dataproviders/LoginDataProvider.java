package io.github.sunnyraj84348.dataproviders;

import com.fasterxml.jackson.core.type.TypeReference;
import io.github.sunnyraj84348.pojo.LoginUser;
import io.github.sunnyraj84348.utils.JsonReader;
import org.testng.annotations.DataProvider;

import java.util.Map;

public class LoginDataProvider {
    @DataProvider(name = "loginData1")
    public Object[][] getInvalidLoginData() {
        Map<String, LoginUser> data = JsonReader.readAsMap(
                "testdata/invalidlogin.json", new TypeReference<Map<String, LoginUser>>() {
                });

        return data.values().stream()
                .map(user -> new Object[]{user.getUsername(), user.getPassword()})
                .toArray(Object[][]::new);
    }

    @DataProvider(name = "loginData2")
    public Object[][] getValidLoginData() {
        Map<String, LoginUser> data = JsonReader.readAsMap(
                "testdata/validlogin.json", new TypeReference<Map<String, LoginUser>>() {
                });

        return data.values().stream()
                .map(user -> new Object[]{user.getUsername(), user.getPassword()})
                .toArray(Object[][]::new);
    }
}
