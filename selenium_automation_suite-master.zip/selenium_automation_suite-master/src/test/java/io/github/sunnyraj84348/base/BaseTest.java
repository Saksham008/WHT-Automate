package io.github.sunnyraj84348.base;

import io.github.sunnyraj84348.driver.DriverFactory;
import io.github.sunnyraj84348.utils.PropertyReader;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import java.time.Duration;

public abstract class BaseTest {
    private static final Logger logger = LoggerFactory.getLogger(BaseTest.class);
    private static String url;

    @Parameters({"browser"})
    @BeforeMethod(alwaysRun = true)
    public void setup(@Optional("chrome") String browser) {
        logger.info("========================================");
        logger.info("Setting up test with browser: {}", browser);
        logger.info("========================================");
        try {
            DriverFactory.initDriver(browser);
            WebDriver driver = DriverFactory.getDriver();
            logger.debug("WebDriver initialized successfully");

            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            logger.debug("Implicit wait set to 10 seconds");

            url = PropertyReader.get("url");
            logger.info("Navigating to {}", url);
            driver.get(url);
            logger.info("✅ Setup completed successfully");
        } catch (Exception e) {
            logger.error("❌ Error during setup: {}", e.getMessage());
            throw e;
        }
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        logger.info("========================================");
        logger.info("Tearing down test - Closing driver");
        logger.info("========================================");
        try {
            DriverFactory.quitDriver();
            logger.info("✅ Teardown completed successfully");
        } catch (Exception e) {
            logger.error("❌ Error during teardown: {}", e.getMessage());
        }
    }
}
