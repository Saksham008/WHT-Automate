package io.github.sunnyraj84348.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ExtentReportManager {
    private static final Logger logger = LoggerFactory.getLogger(ExtentReportManager.class);
    private static ExtentReports extentReports;
    private static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    private static final String REPORT_PATH = "test-output/ExtentReports/";
    // Holds the last generated report file path so external code (listeners/email) can access it
    private static String lastReportFilePath;

    /**
     * Initialize ExtentReports
     */
    public static synchronized void initReports() {
        if (extentReports == null) {
            String timeStamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            String reportName = "ExtentReport_" + timeStamp + ".html";
            String reportFilePath = REPORT_PATH + reportName;

            // store for external use
            lastReportFilePath = reportFilePath;

            logger.info("Initializing ExtentReports with report path: {}", reportFilePath);

            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportFilePath);
            sparkReporter.config().setTheme(Theme.DARK);
            sparkReporter.config().setDocumentTitle("Selenium Automation Suite - Test Report");
            sparkReporter.config().setReportName("Login Test Automation Report");

            extentReports = new ExtentReports();
            extentReports.attachReporter(sparkReporter);
            extentReports.setSystemInfo("OS", System.getProperty("os.name"));
            extentReports.setSystemInfo("Java Version", System.getProperty("java.version"));
            extentReports.setSystemInfo("Browser", "Chrome");
            extentReports.setSystemInfo("Environment", "QA");

            logger.info("ExtentReports initialized successfully");
        }
    }

    /**
     * Create a new test entry in the report
     */
    public static synchronized ExtentTest createTest(String testName, String description) {
        logger.info("Creating test: {} - {}", testName, description);
        ExtentTest test = extentReports.createTest(testName, description);
        extentTest.set(test);
        return test;
    }

    /**
     * Get the current test instance
     */
    public static ExtentTest getTest() {
        return extentTest.get();
    }

    /**
     * Flush the report
     */
    public static synchronized void flushReports() {
        if (extentReports != null) {
            logger.info("Flushing ExtentReports");
            extentReports.flush();
        }
    }

    /**
     * Get the last generated report file path
     */
    public static String getLastReportFilePath() {
        return lastReportFilePath;
    }

    /**
     * Remove test from ThreadLocal
     */
    public static void removeTest() {
        extentTest.remove();
    }
}
