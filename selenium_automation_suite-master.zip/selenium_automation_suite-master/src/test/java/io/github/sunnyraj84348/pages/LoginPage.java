package io.github.sunnyraj84348.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

public class LoginPage {
    private static final Logger logger = LoggerFactory.getLogger(LoginPage.class);
    private final WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//h1[text()='Navigate Withholding Tax']")
    private WebElement whtHeading;

    @FindBy(xpath = "//input[@name='username']")
    private WebElement usernameInput;

    @FindBy(xpath = "//input[@name='password']")
    private WebElement passwordInput;

    @FindBy(xpath = "(//button)[2]")
    private WebElement loginButton;

    @FindBy(xpath = "//div[text()='Incorrect username or password.']")
    private WebElement errorMessage;

    @FindBy(xpath = "//*[text()='Please fill in this field']")
    private WebElement welcomeMessage;

    @FindBy(xpath = "/html/body/div/div/div[3]/main/div/p")
    private WebElement dashboardText;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div[3]/header/div/div/button")
    private WebElement burgerMenuButton;

    @FindBy(xpath = "//*[@id=\"root\"]/div/div[2]/div/nav/div[4]/button")
    private WebElement adminButton;

    public boolean isWhtHeadingVisible() {
        logger.debug("Checking if WHT heading is visible");
        try {
            boolean isVisible = whtHeading.isDisplayed();
            logger.info("WHT heading visibility check: {}", isVisible);
            return isVisible;
        } catch (Exception e) {
            logger.error("Error checking WHT heading visibility: {}", e.getMessage());
            return false;
        }
    }

    public void login(String username, String password) {
        logger.debug("Entering login method with username: {}", username);
        try {
            logger.debug("Entering username: {}", username);
            usernameInput.sendKeys(username);
            logger.debug("Entering password");
            passwordInput.sendKeys(password);
            logger.debug("Clicking login button");
            loginButton.click();
            logger.info("Login attempted successfully with username: {}", username);
        } catch (Exception e) {
            logger.error("Error during login process: {}", e.getMessage());
            throw e;
        }
    }

    public boolean isErrorMessageVisible() {
        logger.debug("Checking if error message is visible");
        try {
            new WebDriverWait(driver, Duration.ofSeconds(30))
                    .until(ExpectedConditions.visibilityOf(errorMessage));
            boolean isVisible = errorMessage.isDisplayed();
            logger.info("Error message visibility: {}", isVisible);
            return isVisible;
        } catch (Exception e) {
            logger.error("Error checking error message visibility: {}", e.getMessage());
            return false;
        }
    }

    public boolean isDashboardTextVisible() {
        logger.debug("Checking if dashboard text is visible");
        try {
            new WebDriverWait(driver, Duration.ofSeconds(30))
                    .until(ExpectedConditions.visibilityOf(dashboardText));
            boolean isDisplayed = dashboardText.isDisplayed();
            boolean containsText = dashboardText.getText().contains("Welcome to the PWC Withholding Tax Dashboard");
            logger.info("Dashboard text visibility: {}, Contains expected text: {}", isDisplayed, containsText);
            return isDisplayed && containsText;
        } catch (Exception e) {
            logger.error("Error checking dashboard text visibility: {}", e.getMessage());
            return false;
        }
    }

    public void navigateToAdminPage() {
        logger.info("Starting navigation to admin page");
        try {
            logger.debug("Current URL before navigation: {}", driver.getCurrentUrl());

            // Navigate directly to admin page using URL navigation
            // Extract base URL from current URL
            String currentUrl = driver.getCurrentUrl();
            String baseUrl = currentUrl.substring(0, currentUrl.indexOf("#"));
            String adminUrl = baseUrl + "#/admin";

            logger.info("Navigating to admin URL: {}", adminUrl);
            driver.navigate().to(adminUrl);

            // Wait for admin page to load
            Thread.sleep(2000);
            logger.info("✅ Successfully navigated to admin page - URL: {}", driver.getCurrentUrl());
        } catch (Exception e) {
            logger.error("❌ Error navigating to admin page: {}", e.getMessage());
            logger.error("Page title: {}", driver.getTitle());
            logger.error("Current URL: {}", driver.getCurrentUrl());
            throw new RuntimeException(e);
        }
    }
}
